This is Microsoft's port of OpenSSH for Windows.
OpenSSH is used for secure remote command execution
and network file transfer (https://www.openssh.com).

THIS IS CURRENTLY BETA SOFTWARE.

Get the latest release here:
   https://github.com/PowerShell/Win32-OpenSSH/releases

For install instructions:
    https://github.com/PowerShell/Win32-OpenSSH/wiki/Install-Win32-OpenSSH

For example uses, project status, troubleshooting, and more:
    https://github.com/PowerShell/Win32-OpenSSH/wiki








