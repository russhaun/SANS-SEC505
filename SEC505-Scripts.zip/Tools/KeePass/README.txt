KeePass is a free and very popular password manager program.

Double-click the file named "Password-is-P@ssword.kdbx" to open
it in KeePass.  The password is "P@ssword" when your are prompted.

Select the PowerShell example and click the URL button in the toolbar
to launch PowerShell with a $Creds variable that contains the
username and password from that KeePass entry.

