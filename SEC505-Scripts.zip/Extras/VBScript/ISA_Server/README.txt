The ISA-Server-Scripts.zip archive contains many scripts
for Microsoft ISA Server and Threat Management Gateway (TMG).
Both products have been discontinued by Microsoft.

