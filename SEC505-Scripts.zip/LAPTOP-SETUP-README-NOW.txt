-----------------------------------------------------

         Welcome to the SANS Institute!
          
-----------------------------------------------------

Please start your Windows Server virtual machine now. 
It will be used immediately once the course begins.  

If you don't have a Windows Server VM, please tell the 
instructor as soon as possible!



-----------------------------------------------------

 Getting Your Virtual Machine Set Up For The Course

-----------------------------------------------------

Please open the first manual (505.1), turn to the first 
lab entitled "On Your Computer" on page 12 or thereabouts, 
then follow the instructions in the lab to get your VM 
set up for the course.

If there are any VM problems, it's best to find them now.

Have Fun!



