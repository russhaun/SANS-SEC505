
These scripts require the free Active Directory cmdlets from Dell/Quest:

   http://software.dell.com/products/activeroles-server/



