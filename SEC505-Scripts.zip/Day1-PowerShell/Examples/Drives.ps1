dir c:\
dir hklm:\
dir hkcu:\
dir variable:\		
dir alias:\
dir cert:\
dir env:\
dir function:\
